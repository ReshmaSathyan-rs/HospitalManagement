package models;

public interface PersonDBActions {
	
	// public User getUser(String name);
	// public void insert(Object obj);
	 public void insert(Person obj);
		public void update(Object obj);
		public void delete(Object obj);
		//public Object Find (Object obj);
	    //public List<T> findAll(Object obj);

}
